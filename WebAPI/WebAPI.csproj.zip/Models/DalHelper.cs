﻿using Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace WebAPI.Models
{
    public class DalHelper
    {
        protected static string GetStringConexao()
        {
            return ConfigurationManager.ConnectionStrings["conexaoSQLServer"].ConnectionString;
        }

        public List<Animais> ListarTodosAnimais()
        {
            List<Animais> _animais = new List<Animais>();

            using (SqlConnection conn = new SqlConnection(GetStringConexao()))
            {
                try
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand("SELECT * FROM ANIMAL", conn))
                    {
                        SqlDataReader dr = cmd.ExecuteReader();

                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                Animais _ani = new Animais();
                                _ani.ani_ID = Convert.ToInt32(dr["ani_ID"]);
                                _ani.ani_NomeCient = dr["ani_NomeCient"].ToString();
                                _ani.ani_Nome = dr["ani_Nome"].ToString();
                                //_ani.ani_IMG = (byte[])dr["ani_IMG"];
                                _ani.ani_Descricao = dr["ani_Descricao"].ToString();
                                _ani.ani_Tipo = Convert.ToInt32(dr["ani_Tipo"]);
                                _animais.Add(_ani);
                            }
                        }
                    }
                }

                catch (Exception)
                {

                    throw;
                }
                finally
                {
                    if (conn.State == System.Data.ConnectionState.Open)
                        conn.Close();
                }

                return _animais;
            }          
        }

    }
}