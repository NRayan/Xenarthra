﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Xenarthra.Models.extra
{
    public class Aparicao_Extended:Aparicao
    {
        public string usu_Nome { get; set; }
        public byte[] usu_IMG { get; set; }
        public string ani_Nome { get; set; }
    }
}
