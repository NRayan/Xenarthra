﻿using System.Collections.Generic;
using Models;
using System.Web.Http;

namespace WebAPI.Models
{
    public class AnimalController : ApiController
    {
        DalHelper _DALHelper = new DalHelper();

        // GET: api/Animal
        [Route("api/1")]
        [HttpGet]
        public IEnumerable<Animais> List()
        {
            return _DALHelper.ListarTodosAnimais();
        }

    }
}